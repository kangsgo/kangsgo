#!/bin/bash
# author:kangsgo 西南交大-小康
# version:1.01beta
# web:http://www.kangsgo.com
# GROMACS GPU一键安装包

echo '
++++++++++++++++++++++++++++++++++++
+  gromacs CUDA版自动化安装	   +
+  适用于 Ubuntu 14.04及16.04版本   +
+  作者：西南交大-康文渊            +
+  版本: 1.0                       +
+  若有问题请联系:347657442@qq.com  +
++++++++++++++++++++++++++++++++++++
'

read -p "输入安装的文件夹" installfile
read -p "输入安装的gmx版本输入
		1.gromacs2016版本
		2.gromacs5.1.X版本
		3.gromacs5.0.X版本" gmx

#更新系统
sudo apt-get install update
echo 'Y'|sudo apt-get upgrade
#设置路径
pwdnew=`echo | pwd`
#获取ubuntu版本
version=`cat /etc/issue | awk '{print $2}'`

if [[ "$version" =~ "14.04" ]]; then
    simplrversion="1"
elif [[ "$version" =~ "16." ]]; then
	simplrversion="2"
else
    echo "本脚本只适用ubuntu14.04以及16版本"
    exit 1
fi
#确定是否有install目录文件
if [ ! -d $installfile ]; then
	mkdir $installfile
fi
#安装常规依赖
echo 'Y'|sudo apt-get install gcc
echo 'Y'|sudo apt-get install g++
echo 'Y'|sudo apt-get install gfortran
#安装cmake
echo 'Y'|sudo apt-get install cmake
cd $installfile
#安装openmpi
wget https://www.open-mpi.org/software/ompi/v2.1/downloads/openmpi-2.1.0.tar.gz
tar xvf openmpi-2.1.0.tar.gz
cd openmpi-2.1.0
./configure -prefix=${pwdnew}/${installfile}/openmpi
make all
make install
#写入bashrc
echo '#openmpi' >> ~/.bashrc
echo "export LD_LIBRARY_PATH=${pwdnew}/${installfile}/openmpi/lib:\$LD_LIBRARY_PATH" >> ~/.bashrc
echo "export PATH=${pwdnew}/${installfile}/openmpi/bin:\$PATH" >> ~/.bashrc
source ~/.bashrc
cd ..

#CUDA安装
if [ $simplrversion == "1" ];
then
	wget http://developer.download.nvidia.com/compute/cuda/repos/ubuntu1404/x86_64/cuda-repo-ubuntu1404_8.0.61-1_amd64.deb
	sudo dpkg -i cuda-repo-ubuntu1404_8.0.61-1_amd64.deb
	echo 'Y'|sudo apt-get update
	echo 'Y'|sudo apt-get install cuda
elif [ $simplrversion="2" ];
then
	wget http://developer.download.nvidia.com/compute/cuda/repos/ubuntu1604/x86_64/cuda-repo-ubuntu1604_8.0.61-1_amd64.deb
	sudo dpkg -i cuda-repo-ubuntu1604_8.0.61-1_amd64.deb
	echo 'Y'|sudo apt-get update
	echo 'Y'|sudo apt-get install cuda
else
	echo "本脚本只适用ubuntu14.04以及16版本,CUDA安装失败"
	exit 1
fi
echo "#CUDA安装"
echo "export PATH=\$PATH:/usr/local/cuda-9.0/bin" >> ~/.bashrc
echo "export LD_LIBRARY_PATH=\$LD_LIBRARY_PATH:/usr/local/cuda-9.0/lib64" >> ~/.bashrc
source ~/.bashrc
cd $installfile
if [ $gmx == "1" ];then
wget ftp://ftp.gromacs.org/pub/gromacs/gromacs-2016.3.tar.gz
tar xfz gromacs-2016.3.tar.gz
cd gromacs-2016.3
elif [ $gmx == "2" ];then
wget ftp://ftp.gromacs.org/pub/gromacs/gromacs-5.1.4.tar.gz
cd gromacs-5.1.4
elif [ $gmx == "3" ];then
wget ftp://ftp.gromacs.org/pub/gromacs/gromacs-5.0.7.tar.gz
else
echo "请选择正确的版本"
exit 1
fi
mkdir build
cd build
cmake .. -DGMX_BUILD_OWN_FFTW=ON -DGMX_GPU=ON -DGMX_MPI=ON -DCMAKE_INSTALL_PREFIX=$pwdnew/install/gromacs
make
make check
make install
echo "#设置gromacs环境" >> ~/.bashrc
echo "source $pwdnew/install/gromacs/bin/GMXRC" >> ~/.bashrc
source ~/.bashrc

