#!/bin/bash
# author:kangsgo
# name: fpocket2 MD 前处理脚本
# method:
#    默认轨迹名称：mdwholeNOjump.xtc，默认tpr为md_0_1.tpr
#    请根据需要修改如下参数
#    总的轨迹数量(ps)
#    numtray=150000
#    每多少间隔提取一次(约150frame)
#    dttray=1000

#设置比对结构,选择蛋白
echo -e "1\n1\n"|trjconv_mpi -f mdwholeNOjump.xtc -s md_0_1.tpr -fit rot+trans -o align.xtc
#创建目录迁移
mkdir fpocket2
cp align.xtc fpocket2/align.xtc
cp md_0_1.tpr fpocket2/md_0_1.tpr
cd fpocket2
#创建txt文件
touch mdpocket_input.txt
#总的轨迹数量(ps)
numtray=150000
#每多少间隔提取一次(约150frame)
dttray=1000
#轨迹变量
numdttray=$[$numtray/$dttray]
echo "轨迹间隔$numdttray"
count=0
num=0
while [ $num -le $numtray ]
do
	echo "数值为$num"
	echo "count数值为$count"
	count=$[ $count +1]
	num=$[$dttray*$count]
	#参数修改为ns，除以1000
	ns=$[$num/1000]
	echo -e "1\n"|trjconv_mpi -f align.xtc -s md_0_1.tpr -dump $num -o snap_$ns.pdb
	#写入文件
	echo "snap_$ns.pdb\n">>mdpocket_input.txt
done
echo "全部完成"
