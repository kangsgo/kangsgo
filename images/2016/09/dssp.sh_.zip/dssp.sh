#!/bin/bash
# author:kangsgo
# method:
#	loop 后面为文件夹变量,表示进入哪个文件夹
#	trj_125-150ns.xtc 轨迹变量
for loop in achmd bnf318 qna tcdd
do
	echo "开始运行"
	cp m2p.m2p /home/gromacs/shiyan/$loop
	cd /home/gromacs/shiyan/$loop 
	do_dssp -f md200skip.xtc -s npt.tpr -n index.ndx -o fwss.xpm 
	xpm2ps -f fwss.xpm -o fwss.eps -by 2 -bx 1 -di m2p.m2p
	convert fwss.eps $loop.bmp 
done
